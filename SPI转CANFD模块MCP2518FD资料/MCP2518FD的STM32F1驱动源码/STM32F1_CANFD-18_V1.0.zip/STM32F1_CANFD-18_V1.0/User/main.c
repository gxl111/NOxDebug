/********************************************************************
filename : main.c
editor   : etk
discript : STM32F1 CANFD EVM driver
time     : 2020.10.14
contact  : edreamtek@163.com
********************************************************************/

#include "main.h"


void etk_watch_dog_init(void);
void etk_can_msg_transmit(void);
int8_t etk_canfd_rcv_poll(void);


extern uint8_t tick;

uint16_t i=0,j;

CANFD_RX_MSG can_rx_msg;
CANFD_TX_MSG can_tx_msg;


int main(void)
{
  RCC_ClocksTypeDef RCC_Clocks;

	/* Extern clock frequency is 8Mhz */
	/* Systerm clock is 72MHz */
	/* HCLK(AHB) is 72MHz */
	/* PCLK1(APB1) is 36MHz */
	/* PCLK2(APB2) is 72MHz */
	/* ADCCLK is 36MHz */
	
  /* SysTick end of count event each 10ms */
  RCC_GetClocksFreq(&RCC_Clocks);
  SysTick_Config(RCC_Clocks.HCLK_Frequency / 100);

	board_led_init();
	board_key_init();
	etk_usart_init();		//���Դ��ڳ�ʼ����������9600
	
	etk_can_init(CAN_500K_5M);		//CANFD��ʼ��
																//���������ʲο���CAN_BITTIME_SETUP������������ò�����û������Ҫ����MCP2518FD�����ֲ���������

	board_led_ctrl(LED1,ON);
	board_led_ctrl(LED2,ON);
	board_led_ctrl(LED3,ON);
	
	printf("STM32F1 CANFD-18 EVM board init OK.\r\n");

	delay_10ms(50);
	board_led_ctrl(LED1,OFF);
	board_led_ctrl(LED2,OFF);
	board_led_ctrl(LED3,OFF);
	
		
	
	can_tx_msg.head.word[0] = 0;
	can_tx_msg.head.word[1] = 0;
	if(1) //��չ֡��ʼ��֡ͷ
	{
			uint32_t id = (0x12345678)>>18 & 0x7FF;
			id |= (0x12345678 & 0x3FFFF)<<11;
			can_tx_msg.head.word[0] = id;
	}
	else	//��׼֡��ʼ��֡ͷ
	{
			can_tx_msg.head.bF.id.SID = 0x123;
	}
	can_tx_msg.head.bF.ctrl.DLC = CAN_DLC_64;	//���Ȳο���CAN_DLC�����壬�����������û�еĲ���
	can_tx_msg.head.bF.ctrl.IDE = 1;	// Extended CAN ID false
	can_tx_msg.head.bF.ctrl.RTR = 0;	// Remote frame
	can_tx_msg.head.bF.ctrl.BRS = TRUE;	//�л����ʣ�Ҳ�������������������ʷ���/����
	can_tx_msg.head.bF.ctrl.FDF = TRUE;	// CAN FD
	for(j=0;j<64;j++)
	{
		can_tx_msg.dat[j] = j;
	}

	etk_can_msg_transmit();

	etk_watch_dog_init();			//���Ź���ʼ��
	
	while(1)
	{
		/* Update IWDG counter */
    IWDG_ReloadCounter();
		
		if(key_pushed)		//����а�������
		{
			key_pushed = 0;	//�������־
			if(key_down[BUTTON_USER1])
			{
				key_down[BUTTON_USER1] = 0;
				board_led_ctrl(LED2,ON);
				etk_can_msg_transmit();
				printf("CAN channel 1 send one message.\r\n");
			}
			else if(key_up[BUTTON_USER1])
			{
				key_up[BUTTON_USER1] = 0;
				board_led_ctrl(LED2,OFF);
			}
			else if(key_down[BUTTON_USER2])
			{
				key_down[BUTTON_USER2] = 0;
				printf("Key2 pushed.\r\n");
			}
			else if(key_up[BUTTON_USER2])
			{
				key_up[BUTTON_USER2] = 0;
			}
			else if(key_down[BUTTON_USER3])
			{
				key_down[BUTTON_USER3] = 0;
				printf("Key3 pushed.\r\n");
			}
			else if(key_up[BUTTON_USER3])
			{
				key_up[BUTTON_USER3] = 0;
			}
		}
		if(Rx_flag)	//�����յ����ݱ�־
		{
			RxBuffer[RxCounter] = 0;	//�����ַ���������
			printf("%s",RxBuffer);
			Rx_flag = 0;		//��������
			RxCounter = 0;	//��������
		}
		
		etk_canfd_rcv_poll();	//��ѯCANFD����
		
		if(can_rx_flag)		//����յ����ݣ��򽫸�֡���ݷ��ͻ�ȥ
		{
			can_rx_flag = FALSE;
			
			can_tx_msg.head.bF.id.EID = can_rx_msg.head.bF.id.EID;
			can_tx_msg.head.bF.id.SID11 = can_rx_msg.head.bF.id.SID11;
			can_tx_msg.head.bF.id.SID = can_rx_msg.head.bF.id.SID;
			can_tx_msg.head.bF.ctrl.DLC = can_rx_msg.head.bF.ctrl.DLC;
			can_tx_msg.head.bF.ctrl.BRS = can_rx_msg.head.bF.ctrl.BRS;
			can_tx_msg.head.bF.ctrl.FDF = can_rx_msg.head.bF.ctrl.FDF;
			can_tx_msg.head.bF.ctrl.IDE = can_rx_msg.head.bF.ctrl.IDE;
			can_tx_msg.head.bF.ctrl.RTR = can_rx_msg.head.bF.ctrl.RTR;
			for(j=0;j<64;j++)
			{
				can_tx_msg.dat[j] = can_rx_msg.dat[j];
			}
			etk_can_msg_transmit();
			printf("CAN Received one message and send back.\r\n");
		}
		if(tick ==1)
		{
			tick = 0;
			board_key_get_value();		//����ɨ��
			
			i++;
			if(i%50 ==0)
			{
				i = 0;
				board_led_toggle(LED1);		//����ָʾ��
			}
		}		
	}
}


/********************************************************************
function: etk_can_rcv_poll
discript: CAN�������ݲ�ѯ.
entrance: none.
return  : ��ȡ��CAN��Ϣ����
********************************************************************/
int8_t etk_canfd_rcv_poll(void)
{
	int8_t pin,res =0;
	CAN_RX_FIFO_EVENT 	rxFlags;
	uint8_t type,len;

	pin= CAN1_RX_INT();
	if(pin) 
	{
		do{
			len = DRV_CANFDSPI_DlcToDataBytes((CAN_DLC)(type&0x0F));
			len +=12;		
			DRV_CANFDSPI_ReceiveMessageGet(CANFD_CH1, CAN_RX_FIFO, &can_rx_msg.head, can_rx_msg.dat, MAX_DATA_BYTES);
		
			res = DRV_CANFDSPI_ReceiveChannelEventGet(CANFD_CH1,CAN_RX_FIFO,&rxFlags);
			if(res<0)
			{		
				res = 0;				
				break;
			}
		}while(rxFlags & CAN_RX_FIFO_NOT_EMPTY_EVENT);
			
		can_rx_flag = TRUE;
	}
	return TRUE;
}


void etk_can_msg_transmit(void)
{
	if(0==etk_can_transmit_check_fifo(CANFD_CH1))
	{
		if(etk_can_transmit_msg(CANFD_CH1,&can_tx_msg) ==CAN_TRANS_SUCCESS)
		{
			//���ͳɹ�
		}
		else
		{
			//����ʧ��
		}
	}
}

#define IWDG_PER             IWDG_Prescaler_256 
#define IWDG_CNT             625 // 4s timeout
/********************************************************************
function: etk_watch_dog_init
discript: ���Ź���ʼ��
entrance: ��
return  : ��
********************************************************************/
void etk_watch_dog_init(void)
{
	// First Open LSI Clock for IWDG
  RCC_LSICmd(ENABLE);
  while (RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET);
 
  // If use IWDG, LSI will be opened force
  IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
  // Set Prescaler
  IWDG_SetPrescaler(IWDG_PER);
  // Set reload value
  IWDG_SetReload(IWDG_CNT);
  // Set 0xAAAA To make sure not go into reset
  IWDG_ReloadCounter();
  // Enable WDG
  IWDG_Enable();
}


